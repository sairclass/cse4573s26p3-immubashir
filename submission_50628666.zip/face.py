'''
Notes:
1. All of your implementation should be in this file. This is the ONLY .py file you need to edit & submit. 
2. Please Read the instructions and do not modify the input and output formats of function detect_faces() and cluster_faces().
3. If you want to show an image for debugging, please use show_image() function in helper.py.
4. Please do NOT save any intermediate files in your final submission.
'''


import torch

import face_recognition

from typing import Dict, List
from utils import show_image

'''
Please do NOT add any imports. The allowed libraries are already imported for you.
'''

def detect_faces(img: torch.Tensor) -> List[List[float]]:
    """
    Args:
        img : input image is a torch.Tensor represent an input image of shape H x W x 3.
            H is the height of the image, W is the width of the image. 3 is the [R, G, B] channel (NOT [B, G, R]!).

    Returns:
        detection_results: a python nested list. 
            Each element is the detected bounding boxes of the faces (may be more than one faces in one image).
            The format of detected bounding boxes a python list of float with length of 4. It should be formed as 
            [topleft-x, topleft-y, box-width, box-height] in pixels.
    """
    """
    Torch info: All intermediate data structures should use torch data structures or objects. 
    Numpy and cv2 are not allowed, except for face recognition API where the API returns plain python Lists, convert them to torch.Tensor.
    
    """
    detection_results: List[List[float]] = []

    ##### YOUR IMPLEMENTATION STARTS HERE #####

    img_hwc = _to_hwc_uint8(img)

    candidates = [img_hwc, _flip_channels_hwc(img_hwc)]

    best_locations = []
    best_score = -1.0

    for candidate in candidates:
        locations = _detect_face_locations(candidate)

        score = float(len(locations)) * 1e12 + _total_box_area(locations)
        if score > best_score:
            best_score = score
            best_locations = locations
    
    H, W = img_hwc.shape[0], img_hwc.shape[1]
    detection_results = _locations_to_xywh(best_locations, H, W)

    return detection_results



def cluster_faces(imgs: Dict[str, torch.Tensor], K: int) -> List[List[str]]:
    """
    Args:
        imgs : input images. It is a python dictionary
            The keys of the dictionary are image names (without path).
            Each value of the dictionary is a torch.Tensor represent an input image of shape H x W x 3.
            H is the height of the image, W is the width of the image. 3 is the [R, G, B] channel (NOT [B, G, R]!).
        K: Number of clusters.
    Returns:
        cluster_results: a python list where each elemnts is a python list.
            Each element of the list a still a python list that represents a cluster.
            The elements of cluster list are python strings, which are image filenames (without path).
            Note that, the final filename should be from the input "imgs". Please do not change the filenames.
    """
    """
    Torch info: All intermediate data structures should use torch data structures or objects. 
    Numpy and cv2 are not allowed, except for face recognition API where the API returns plain python Lists, convert them to torch.Tensor.
    
    """
    cluster_results: List[List[str]] = [[] for _ in range(K)] # Please make sure your output follows this data format.
        
    ##### YOUR IMPLEMENTATION STARTS HERE #####
    img_names = sorted(list(imgs.keys()))
    features = []

    for img_name in img_names:
        feature = _extract_face_embedding(imgs[img_name])
        features.append(feature)

    X = torch.stack(features, dim = 0)

    X = _l2_normalize(X)

    labels = _kmeans_torch(X, K)

    for img_name, label in zip(img_names, labels.tolist()):
        cluster_results[int(label)].append(img_name)

    return cluster_results


'''
If your implementation requires multiple functions. Please implement all the functions you design under here.
But remember the above 2 functions are the only functions that will be called by task1.py and task2.py.
'''

# TODO: Your functions. (if needed)

def _to_hwc_uint8(img: torch.Tensor) -> torch.Tensor:
    if img.dim() != 3:
        raise RuntimeError("Input image must be a 3D torch.Tensor")
    # CHW -> HWC
    if img.shape[0] == 3 and img.shape[-1] != 3:
        img_hwc = img.permute(1, 2, 0)
    else:
        img_hwc = img
    
    if img_hwc.dtype != torch.uint8:
        img_hwc = img_hwc.clamp(0, 255).to(torch.uint8)
    
    return img_hwc

def _flip_channels_hwc(img_hwc: torch.Tensor) -> torch.Tensor:

    #RGB <-> BGR for HWC images

    return torch.flip(img_hwc, dims=[2]).contiguous()

def _detect_face_locations(img_hwc: torch.Tensor):
    img_np = img_hwc.numpy()

    best_locations = []
    best_area = -1.0

    for upsample in [0, 1, 2]:
        try:
            locations = face_recognition.face_locations(
                img_np,
                number_of_times_to_upsample = upsample,
                model="hog"
            )
        except Exception:
            locations = []
        
        area = _total_box_area(locations)
        if len(locations) > len(best_locations) or (len(locations) == len(best_locations) and area > best_area) :
            best_locations = locations
            best_area = area

    return best_locations

def _total_box_area(locations) -> float:
    total = 0.0
    for (top, right, bottom, left) in locations:
        w = max(0, right - left)
        h = max(0, bottom - top)
        total += float(w * h)
    return total

def _locations_to_xywh(locations, H: int, W: int) -> List[List[float]]:
    results: List[List[float]] = []
    
    for(top, right, bottom, left) in locations:
        left = max(0, min(int(left), W - 1))
        top = max(0, min(int(top), H - 1))
        right = max(left+1, min(int(right), W))
        bottom = max(top+1, min(int(bottom), H))

        x = float(left)
        y = float(top)
        w = float(right-left)
        h = float(bottom-top)

        results.append([x, y, w, h])
    
    return results

def _extract_face_embedding(img: torch.Tensor) -> torch.Tensor:
    img_hwc = _to_hwc_uint8(img)
    candidates = [img_hwc, _flip_channels_hwc(img_hwc)]

    best_embedding = None
    best_area = -1.0

    for candidate in candidates:
        img_np = candidate.numpy()
        locations = _detect_face_locations(candidate)

        if len(locations) == 0:
            try:
                encodings = face_recognition.face_encodings(img_np)
            except Exception:
                encodings = []
            
            if len(encodings) > 0:
                emb = torch.tensor(encodings[0], dtype = torch.float32)
                return emb
            continue

        indexed = []
        for loc in locations:
            top, right, bottom, left = loc
            area = float(max(0, right - left) * max(0, bottom-top))
            indexed.append((area, loc))
        indexed.sort(key = lambda x: x[0], reverse = True)

        sorted_locations = [item[1] for item in indexed]

        try:
            encodings = face_recognition.face_encodings(
                img_np,
                known_face_locations=sorted_locations
            )
        except Exception:
            encodings = []
        
        for i, enc in enumerate(encodings):
            area = indexed[i][0]
            if area > best_area:
                best_area = area
                best_embedding = torch.tensor(enc, dtype=torch.float32)
                
    if best_embedding is None:
        best_embedding = torch.zeros(128, dtype=torch.float32)
    
    return best_embedding

def _l2_normalize(x: torch.Tensor) -> torch.Tensor:
    norms = torch.sqrt(torch.sum(x * x, dim = 1, keepdim=True) +1e-12)
    return x / norms

def _init_centers_farthest_first(X: torch.Tensor, K:int) -> torch.Tensor:
    N, D = X.shape
    centers = torch.zeros((K, D), dtype=X.dtype)

    first_idx = torch.argmax(torch.sum(X * X, dim=1))
    centers[0] = X[first_idx]

    min_dist2 = torch.sum((X - centers[0]) * (X - centers[0]), dim=1)

    for k in range(1, K):
        next_idx = torch.argmax(min_dist2)
        centers[k] = X[next_idx]
        dist2 = torch.sum((X - centers[k]) * (X - centers[k]), dim=1)
        min_dist2 = torch.minimum(min_dist2, dist2)

    return centers

def _kmeans_torch(X: torch.Tensor, K: int, max_iter: int=100) -> torch.Tensor:

    N = X.shape[0]

    if K <= 0:
        raise RuntimeError("K must be positive")
    if N == 0:
        raise RuntimeError("No input provided")
    if K > N:
        K = N
    
    centers = _init_centers_farthest_first(X, K)
    prev_labels = None

    for _ in range(max_iter):
        dists = torch.cdist(X, centers, p=2)
        labels = torch.argmin(dists, dim=1)

        if prev_labels is not None and torch.equal(labels, prev_labels):
            break
        
        new_centers = centers.clone()

        min_dists, _ = torch.min(dists, dim=1)

        for k in range(K):
            mask = (labels == k)
            if torch.any(mask):
                new_centers[k] = torch.mean(X[mask], dim=0)
            else:
                farthest_idx = torch.argmax(min_dists)
                new_centers[k] = X[farthest_idx]
        centers = new_centers
        prev_labels = labels.clone()
    
    final_dists = torch.cdist(X, centers, p=2)
    final_labels = torch.argmin(final_dists, dim=1)
    return final_labels